/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package resumebuilder;

/**
 *
 * @author imadi
 */
public class ResumeBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        loginPage a = new loginPage();
        a.setVisible(true);
    }
    
}
